from django.db import models
from django.db.models.fields import EmailField
class sign(models.Model):
    name=models.CharField(max_length=20)
    email=models.EmailField(max_length=40)
    password=models.CharField(max_length=20)
    confirmpass=models.CharField(max_length=20)
    address=models.CharField(max_length=20)
    class Meta:
        db_table="sign"