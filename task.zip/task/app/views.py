from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from app.models import sign
def signup(request):
    if request.method=='POST':
        s=sign()
        s.name=request.POST['name']
        s.email=request.POST['email']
        s.password=request.POST['pwd']
        s.confirmpass=request.POST['cpwd']
        s.address=request.POST['add']
        s.save()
    return render(request,'signup.html')   
def login(request):
    if request.method=='POST':
        email=request.POST['email']
        password=request.POST['pwd']
        user=sign.objects.filter(email=email,password=password)
        if user:
            return render(request,'show.html')
        else:
            return render(request,'login.html',{'data':'invalid user please enter correct password'})    
    return render(request,'login.html')
@login_required    
def show(request):
    data=sign.objects.all()
    return render(request,'show.html',{'s':data})
@login_required
def update(request,id):
    if request.method=='POST':
        s=sign(request.POST)
        s=sign.objects.get(id=id)
        s.name=request.POST['name']
        s.email=request.POST['email']
        s.password=request.POST['pwd']
        s.confirmpass=request.POST['cpwd']
        s.address=request.POST['add']
        s.save()
        data=sign.objects.all()
        return render(request,'show.html',{'s':data})
    return render(request,'signup.html')
@login_required
def delete(request,id):
    obj=sign.objects.get(id=id).delete()
    data=sign.objects.all()
    return render(request,'show.html',{'s':data}) 
def logout(request):
    return render(request,'signup.html',{'msg':"Thank You for login"})               